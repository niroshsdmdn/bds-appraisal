import copy
import csv
import io
import os
from datetime import date
from pathlib import Path

import pytest
from openpyxl import load_workbook

from appraisal.ai_review import _content_blocks, _parse_json, merge_ai
from appraisal.checks import appraise, decode_nic
from appraisal.extract import extract, fix_split_numbers, to_number
from appraisal.parse import parse
from appraisal.report import build_excel, build_html

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_XLSX = ROOT / "samples" / "sample_proposal_fictional.xlsx"
SAMPLE_CSV = ROOT / "samples" / "sample_proposal_fictional.csv"


@pytest.fixture(scope="session", autouse=True)
def samples():
    if not SAMPLE_XLSX.exists():
        import runpy
        runpy.run_path(str(ROOT / "samples" / "make_sample.py"), run_name="__main__")


def run(path: Path):
    ex = extract(path.name, path.read_bytes())
    p = parse(ex)
    return ex, p, appraise(p)


def csv_bytes(rows):
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    return buf.getvalue().encode()


def test_number_helpers():
    assert fix_split_numbers("Total 1 5,295.83 26000") == "Total 15,295.83 26000"
    assert fix_split_numbers("Percapita Income 8 ,772.29") == "Percapita Income 8,772.29"
    assert to_number("9 5,900.00") == 95900.0
    assert to_number("-") == 0.0
    assert to_number("Food") is None


def test_nic_decoding():
    old = decode_nic("895044695V", date(2026, 4, 7))
    assert old["gender"] == "female" and old["age"] == 37 and old["born"] == date(1989, 1, 4)
    new = decode_nic("199012300123", date(2026, 1, 1))
    assert new["gender"] == "male" and new["born"].year == 1990
    assert decode_nic("12345", date.today())["valid"] is False


def test_xlsx_and_csv_agree_and_score_high():
    _, p1, a1 = run(SAMPLE_XLSX)
    _, p2, a2 = run(SAMPLE_CSV)
    assert a1.total == a2.total
    assert a1.total >= 75
    assert a1.decision()["label"] == "Approve"
    assert not a1.critical
    assert len(p1.members) == 4 and len(p1.equipment) == 3 and len(p1.risks) == 4
    assert p1.current.per_capita == 7500 and p1.expected.total_income == 35275
    assert p1.annual["sales"] == [360000, 468000]


def test_defects_are_caught_and_cap_the_decision():
    from samples import make_sample as ms  # noqa: WPS433
    rows = copy.deepcopy(ms.ROWS)
    rows[4][0] = rows[4][0].replace("she, her husband", "he, his wife") + \
        " This plan supports a business in No 7 Division, Hillcrest Estate."
    rows[7][1] = 45                              # family-table age disagrees with NIC
    rows[18][2] = 31000                          # wrong income total
    rows[49][2] = 900000                         # annual sale no longer matches section 6
    ex = extract("defects.csv", csv_bytes(rows))
    a = appraise(parse(ex))
    status = {c.id: c.status for c in a.checks}
    assert status["C2.2"] == "fail"
    assert status["C2.3"] == "fail"
    assert status["C2.4"] == "fail"
    assert status["C4.1"] in {"fail", "partial"}
    assert any(c.id == "C2.4" for c in a.critical)
    assert a.decision()["label"] in {"Revise and resubmit", "Not recommended"}
    plan = a.improvement_plan()
    assert plan and plan[0]["severity"] == "critical"


def test_unsupported_file_type():
    with pytest.raises(ValueError):
        extract("proposal.docx", b"x")


def test_ai_merge_blends_scores_and_adds_findings():
    ex, _, a = run(SAMPLE_XLSX)
    before = a.criteria["C3"].rule_score
    fake = _parse_json("""```json
    {"summary": "ok", "criteria": [{"id": "C3", "score": 5, "rationale": "thin market data"}],
     "findings": [{"criterion": "C5", "severity": "major", "finding": "Pump price looks high",
                   "suggestion": "Attach a third quotation", "mark_gain": 1.5}],
     "disagreements": [], "recommended_decision": "Approve with conditions", "conditions": []}
    ```""")
    merge_ai(a, fake, ai_weight=0.5)
    assert a.criteria["C3"].ai_score == 5
    assert a.criteria["C3"].score == pytest.approx((before + 5) / 2)
    assert any(r["source"] == "ai" and r["mark_gain"] == 1.5 for r in a.improvement_plan())
    blocks = _content_blocks(ex)
    assert blocks[0]["type"] == "text" and "Ravenswood" in blocks[0]["text"]


def test_reports_build():
    _, p, a = run(SAMPLE_XLSX)
    meta = {"file_name": "sample.xlsx", "user": "Test", "role": "Reviewer",
            "audit": [{"when": "now", "who": "Test", "role": "reviewer", "action": "Opened", "detail": ""}]}
    wb = load_workbook(io.BytesIO(build_excel(p, a, meta)))
    assert {"Summary", "Criteria", "Findings", "Improvement plan", "Extracted data", "Audit trail"} <= set(wb.sheetnames)
    assert "Livelihood proposal appraisal" in build_html(p, a, meta)


@pytest.mark.skipif(not os.environ.get("PROPOSAL_PDF"), reason="set PROPOSAL_PDF to a real template PDF")
def test_real_pdf():
    ex, p, a = run(Path(os.environ["PROPOSAL_PDF"]))
    assert p.members and p.equipment and p.annual.get("sales")
    assert 0 <= a.total <= 100
