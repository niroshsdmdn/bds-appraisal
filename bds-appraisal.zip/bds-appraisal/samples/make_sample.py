"""Build a fictional sample proposal in the BDS template layout (XLSX + CSV).

All names, NIC and phone numbers are invented. Run:
    python samples/make_sample.py
"""
from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

HERE = Path(__file__).parent

NARRATIVE = (
    "Family background :- Mrs.K.Nirmala is 36 years old and lives in Upper Division, Ravenswood "
    "Estate, Nuwara Eliya. Four members live in this family: she, her husband and two children. "
    "She has 8 years of experience growing carrot and leeks on 40 perches of land. The family's "
    "monthly income is Rs. 30,000 against spending of Rs. 32,000, and they buy on shop credit to "
    "cover the gap. She already owns hand tools worth Rs. 8,000. She waters the plot by hand, which "
    "limits the area she can cultivate, and loses part of each crop to pests. She requests a water "
    "pump, hose and sprayer to irrigate 60 perches and control pests."
)
OVERVIEW = (
    "Mrs. Nirmala grows carrot and leeks in two seasons (Maha and Yala) on 40 perches. With "
    "irrigation she will extend to 60 perches and plant a third short crop of beans. Current yield "
    "is about 1,200 kg per season sold to two collectors and at the Nuwara Eliya economic centre at "
    "an average Rs. 150 per kg. Year-1 sales assume 1,560 kg per season at the same price. "
    "Quotations from two Nuwara Eliya suppliers are attached for the pump, hose and sprayer."
)

ROWS: list[list] = [
    ["BERENDINA DEVELOPMENT SERVICES (GTE) LTD"],
    ["1 Name of the Livelihood and Period Involve"],
    ["Vegetable cultivation - 8 years of experience"],
    ["2) Overview of the Family and Livelihood and their Goal"],
    [NARRATIVE],
    ["Family Details"],
    ["Name", "Age", "Relationship", "Health Condition"],
    ["K.Nirmala", 36, "HHH", "Good"],
    ["S.Murugan", 40, "Husband", "Good"],
    ["M.Kavin", 12, "Son", "Good"],
    ["M.Tharani", 9, "Daughter", "Good"],
    ["2.2 Current Income and Expenditure of the family"],
    ["Income", "", "", "Expenditure", ""],
    ["Source", "Earner", "Gain Rs", "Description", "Cost Rs"],
    ["Cultivation", "K.Nirmala", 12000, "Food", 24000],
    ["Estate Work", "S.Murugan", 18000, "Electricity", 1500],
    ["", "", "", "Education", 4000],
    ["", "", "", "Health", 2500],
    ["Total", "", 30000, "", 32000],
    ["No of Family Members", "", 4],
    ["Percapita Income", "", 7500],
    ["2.3 Expected Income and Expenditure of the family after Livelihood Support"],
    ["Income", "", "", "Expenditure", ""],
    ["Source", "Earner", "Gain Rs", "Description", "Cost Rs"],
    ["Cultivation", "K.Nirmala", 17275, "Food", 24000],
    ["Estate Work", "S.Murugan", 18000, "Electricity", 1500],
    ["", "", "", "Education", 4000],
    ["", "", "", "Health", 2500],
    ["Total", "", 35275, "", 32000],
    ["No of Family Members", "", 4],
    ["Percapita Income", "", 8818.75],
    ["Change of Percapita income", "", 1318.75],
    ["2.4 Overview of the Livelihood"],
    [OVERVIEW],
    ["The support she/he required for the LH)", "", "", "Water pump motor 2HP / Hose 100ft / Knapsack sprayer"],
    ["Goal", 1, "Increase monthly livelihood income by 40% within 12 months"],
    ["", 2, "Save Rs. 2,000 per month in a bank account for repairs and inputs"],
    ["", 3, "Cultivate 60 perches in two seasons plus one short bean crop"],
    ["3 Personal Detail"],
    ["1.Name", "K.Nirmala"],
    ["2.Address", "Upper Division Ravenswood"],
    ["3.NIC No.", "906201234V"],
    ["4.Contact No", "0771234567"],
    ["5. Age", 36],
    ["4 Livelihood Detail"],
    ["Reg. No", "Nil"],
    ["Business Address", "Upper Division Ravenswood"],
    ["Product/Service", "Vegetable cultivation"],
    ["Market", "Nuwara Eliya economic centre and two collectors"],
    ["Annual Sale", ":", 468000],
    ["Annual profit", ":", 207300],
    ["5 Investment"],
    ["", "Description", "", "Total", "Own", "", "Expectation Loan/Grant Rs."],
    ["", "", "", "", "Invested", "Proposed", ""],
    ["", "Fixed Asset", "Land", "-", "", "", ""],
    ["", "", "Machinery", 38000, "", "", 38000],
    ["", "", "Equipment", 38500, 8000, "", 30500],
    ["", "", "Total", 76500, 8000, "-", 68500],
    ["", "Working Capital", "Seeds", 12500, "", 12500, ""],
    ["", "", "Manpower &", 11250, "", 11250, ""],
    ["", "", "Land preparing", 7500, "", 7500, ""],
    ["", "", "Fertilizer", 15500, "", 15500, ""],
    ["", "", "Chemicals", 12000, "", 12000, ""],
    ["", "", "Total", 58750, "", 58750, "-"],
    ["", "Total - Investment", "", 135250, 8000, 58750, 68500],
    ["", "Percentage Contribution", "", 100, 5.91, 43.44, 50.65],
    ["6 Expenditure & Income Annual"],
    ["", "", "Current", "", "1st Year Expectation", ""],
    ["", "Description", "Expenditure", "Income", "Expenditure", "Income"],
    ["", "Sales income", "", 360000, "", 468000],
    ["", "Seeds", 40000, "", 50000, ""],
    ["", "Manpower &", 36000, "", 45000, ""],
    ["", "Land preparing", 30000, "", 30000, ""],
    ["", "Fertilizer", 50000, "", 62000, ""],
    ["", "Chemicals", 40000, "", 48000, ""],
    ["", "Machine rent", 20000, "", "-", ""],
    ["", "Depriciations", "-", "", 13700, ""],
    ["", "Marketing Expenses", "-", "", 12000, ""],
    ["", "Total Expenditure", 216000, "", 260700, ""],
    ["", "Total Income", "", 360000, "", 468000],
    ["", "Profit/Loss", "", 144000, "", 207300],
    ["7 Detail of Needed Equipment & Inputs"],
    ["No", "Equipment & Inputs Needed", "Qty", "Unit price", "Total", "BDS contribution", "Other's Contribution"],
    [1, "Water pump motor 2HP", 1, 38000, 38000, 38000, "-"],
    [2, "Rubber hose 1'' 100ft", 1, 12500, 12500, 12500, "-"],
    [3, "Knapsack sprayer", 1, 18000, 18000, 18000, "-"],
    ["", "", "", "", 68500, 68500, "-"],
    ["8 Possible Risk to the Livelihood and Mitigation Mechanism"],
    ["", "Possible Risks", "Mitigation Mechanism"],
    [1, "Market price drop at harvest", "Stagger planting and sell to two collectors; CDC shares weekly price updates"],
    [2, "Heavy rain and landslide", "Contour drains before each season with the Agriculture Instructor"],
    [3, "Wild boar and porcupine damage", "Family repairs live fence before each season"],
    [4, "Pump motor breakdown", "Service the motor each season; save Rs. 500 monthly for repairs"],
    ["9 Detail of Needed Trainings"],
    ["No.", "Traineed Needed", "Additional information"],
    [1, "Technical Training on vegetable cultivation", "Irrigation scheduling, IPM, seed selection"],
    [2, "Record keeping and costing", "Farm diary, cost per kg, savings planning"],
    ["10 Pictures of Beneficiary or Location"],
    ["11 Prepared by (Name, Designation and Date):", "S.Kumar - CDC - 2026.05.10"],
    ["12 Varified officer (Name, Desigantion and Date):", "P.Rajan - ARM - 2026.05.14"],
    ["13 Approved by (Name, Designation and Date):", ""],
]


def main() -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Proposal"
    for row in ROWS:
        ws.append(row)
    for r in ws.iter_rows():
        for c in r:
            c.font = Font(name="Arial")
    ws.column_dimensions["A"].width = 48
    wb.save(HERE / "sample_proposal_fictional.xlsx")
    with open(HERE / "sample_proposal_fictional.csv", "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(ROWS)
    print("Wrote sample_proposal_fictional.xlsx and .csv")


if __name__ == "__main__":
    main()
